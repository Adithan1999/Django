from django.http import request
from django.shortcuts import render,redirect
from django.contrib import messages
from . models import Imageadd

# Create your views here.
def home(request):
    return render(request,'home.html')

def show(request):
    products=Imageadd.objects.all()
    context={'products':products}
    return render(request,'show.html',context)

def adding(request):
    if request.method == 'POST':
        prod = Imageadd()
        prod.f_name = request.POST.get('f_name')
        prod.l_name = request.POST.get('l_name')
        prod.emailid = request.POST.get('emailid')
        if len(request.FILES) != 0:
            prod.image = request.FILES['imagefile']

        prod.save()
        messages.success(request,"saved")
        return redirect('home')    
       
    return render(request, 'show.html')