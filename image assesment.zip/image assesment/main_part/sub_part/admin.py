from django.contrib import admin
from . models import Imageadd

# Register your models here.
admin.site.register(Imageadd)
